/* The code that simulates and tests your address verification.  How
   this is done is disclosed. As a student you shall not compile this
   file, but instead compile your program with the .o file as:

   gcc -Wall -Wextra -std=c99 -pedantic -m32 -g verify_adr.c pagedir.o
 */
// #error Read comment above. Leave this line in place.

