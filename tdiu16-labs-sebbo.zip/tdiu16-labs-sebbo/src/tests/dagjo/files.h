// Parameters for check-close.c:

// Name of the file.
#define FILE_NAME "large-file"
// Size picked to fill more than 50% of the disk (the disk is 2MB)
#define FILE_SIZE (1024 + 256)*1024

