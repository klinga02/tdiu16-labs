#define BIG 3000
#define TIMES 200 // change to 500 or larger if running without the -S flag
